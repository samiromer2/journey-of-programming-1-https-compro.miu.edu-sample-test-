# MUM/MIU Practice Test Question Katas

The purpose of this short test is to assess your ability to solve elementary programming problems in a language of your choice.

Write your solutions in Java if you're familiar with that language,otherwise use one of these languages: C,C++,or C#

For each of the problems, write the simplest, clearest solution you can, in the form of a short program.

These Practice Test Question Katas will help you prepare for MIU Test Required to Join MIU MSCS Program.\
Practice, Practice, Practice.

**NOTE:** Try out the Test Question first, and maybe Later compare with my Solution.

**#Happy Learning**
